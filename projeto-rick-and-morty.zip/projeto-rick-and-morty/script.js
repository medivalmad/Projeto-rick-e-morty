const container = document.getElementById("characters-container");

async function getCharacters(){

  try{

    const response = await fetch("https://rickandmortyapi.com/api/character");

    const data = await response.json();

    data.results.forEach(character => {

      // Card principal
      const card = document.createElement("div");
      card.classList.add("card");

      // Imagem
      const image = document.createElement("img");
      image.src = character.image;
      image.alt = character.name;

      // Conteúdo
      const content = document.createElement("div");
      content.classList.add("card-content");

      // Nome
      const name = document.createElement("h3");
      name.textContent = character.name;

      // Espécie
      const species = document.createElement("p");
      species.textContent = `Espécie: ${character.species}`;

      // Gênero
      const gender = document.createElement("p");
      gender.textContent = `Gênero: ${character.gender}`;

      // Status
      const status = document.createElement("span");
      status.textContent = character.status;
      status.classList.add("status");

      if(character.status === "Alive"){
        status.classList.add("alive");
      }
      else if(character.status === "Dead"){
        status.classList.add("dead");
      }
      else{
        status.classList.add("unknown");
      }

      // Append
      content.appendChild(name);
      content.appendChild(species);
      content.appendChild(gender);
      content.appendChild(status);

      card.appendChild(image);
      card.appendChild(content);

      container.appendChild(card);

    });

  }

  catch(error){

    console.log("Erro ao buscar personagens:", error);

    container.innerHTML = `
      <p>Erro ao carregar personagens.</p>
    `;

  }

}

getCharacters();